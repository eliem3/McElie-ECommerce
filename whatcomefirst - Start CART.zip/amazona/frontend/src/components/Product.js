import { Card } from 'react-bootstrap';
import { Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import Rating from '../components/Rating';

function Product(props) {
  const { product } = props;
  return (
    <Card className="card">
      <Link to={`/product/${product.slug}`}>
        <img
          className="birdy-name card-img-top"
          src={product.image}
          alt={product.name}
        />
      </Link>
      <Card.Body>
        <div className="card-text-body">
          <Link to={`/product/${product.slug}`}>
            <Card.Title className="card-title">{product.name}</Card.Title>
          </Link>
          <Rating rating={product.rating} numReviews={product.numReviews} />
          <Card.Text className="card-description">
            {product.currency}
            {product.currentPrice}
          </Card.Text>
          <Button variant="primary" className="btn btn-primary">
            Add to cart
          </Button>
        </div>
      </Card.Body>
    </Card>
  );
}
export default Product;
