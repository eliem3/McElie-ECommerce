import jwt from 'jsonwebtoken';

export const generateToken = (user) => {
  return jwt.sign(
    //instead of passing all users information, we will pass only 4 items
    {
      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
    },
    process.env.JWT_SECRET,
    {
      //set password token to exprired after 30 days
      expiresIn: '30d',
    });
};
