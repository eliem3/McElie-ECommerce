import { Card } from 'react-bootstrap';
import { Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';

function Product(props) {
  const { product } = props;
  return (
    <Card className="flex-column flex-marg">
      <Link to={`/product/${product.slug}`}>
        <img
          className="birdy-name card-img-top"
          src={product.image}
          alt={product.name}
        />
      </Link>
      <Card.Body>
        <div className="card-text-body">
          <Link to={`/product/${product.slug}`}>
            <Card.Title>{product.name}</Card.Title>
          </Link>
          <Card.Text>
            <strong>{product.currency}</strong> {product.currentPrice}
          </Card.Text>
          <Button variant="primary" className="btn btn-primary">
            Add to cart
          </Button>
        </div>
      </Card.Body>
    </Card>
  );
}
export default Product;
